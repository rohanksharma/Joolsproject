<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StoneShap extends Model
{
    //
    protected $table = 'shape';
    protected $fillable = ['id', 'shape', 'shape','status'];
}
