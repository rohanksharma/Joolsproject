<?php

namespace App\DTO;


class ProductMaterial
{
            public $CSlavel;
            public $AS1lavel;
            public $AS2lavel;
            public $centerStone;
            public $accentStone1;
            public $accentStone2;
            public $umetal;
            public $metalProductDetails;
            public $metalFinish;
            public $productsku;
}
